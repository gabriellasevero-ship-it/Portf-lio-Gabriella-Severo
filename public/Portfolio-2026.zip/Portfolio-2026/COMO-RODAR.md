# Portfolio-2026

Para rodar na sua máquina:

```bash
cd Portfolio-2026
npm install
npm run dev
```

Abra http://127.0.0.1:43123

Coloque a foto em `public/images/profile/` e os cases em `public/images/cases/`.
